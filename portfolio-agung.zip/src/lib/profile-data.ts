export const PROFILE = {
  name: "Agung Ramadhan Setiawan",
  role: "Web Developer",
  tagline: "Lulusan D4 Teknik Informatika — Politeknik Negeri Lhokseumawe",
  location: "Lhokseumawe, Aceh",
  email: "agung.ramadhan@example.com",
  // Formal photo — leave empty to show the AR monogram placeholder.
  // Set to a CDN asset URL (from .asset.json) once a photo is uploaded.
  photo: "",
  about:
    "Saya seorang web developer yang fokus membangun aplikasi web yang responsif, cepat, dan rapi. Saya senang mengubah ide menjadi antarmuka yang interaktif, dan terus belajar teknologi baru untuk menghasilkan produk yang berkualitas.",
  stats: [
    { value: "D4", label: "Teknik Informatika" },
    { value: "10+", label: "Proyek & Tugas" },
    { value: "8+", label: "Teknologi dikuasai" },
  ],
  skills: [
    { name: "HTML", level: 95 },
    { name: "CSS / Tailwind", level: 90 },
    { name: "JavaScript", level: 85 },
    { name: "React", level: 80 },
    { name: "PHP / Laravel", level: 82 },
    { name: "MySQL", level: 80 },
    { name: "Git", level: 78 },
    { name: "Node.js", level: 70 },
  ],
  projects: [
    {
      title: "Sistem Informasi Akademik",
      desc: "Aplikasi web manajemen data mahasiswa, KRS, dan nilai berbasis Laravel + MySQL dengan dashboard admin dan role guru.",
      tags: ["Laravel", "MySQL", "Bootstrap"],
      accent: "coral",
      link: "#",
    },
    {
      title: "Portfolio Interaktif",
      desc: "Website portofolio pribadi dengan animasi smooth, dark mode, dan layout responsif — dibangun dengan React & Tailwind.",
      tags: ["React", "Tailwind", "Motion"],
      accent: "gold",
      link: "#",
    },
    {
      title: "E-Commerce UMKM",
      desc: "Toko online untuk produk UMKM lengkap dengan keranjang, katalog, dan pembayaran. Frontend interaktif + backend REST API.",
      tags: ["React", "Node.js", "MySQL"],
      accent: "coral",
      link: "#",
    },
    {
      title: "Absensi QR Code",
      desc: "Aplikasi absensi berbasis pemindaian QR untuk siswa, dengan rekapitulasi otomatis dan ekspor laporan.",
      tags: ["Laravel", "QR", "MySQL"],
      accent: "gold",
      link: "#",
    },
  ],
  organizations: [
    {
      role: "Penanggung Jawab Media Sosial",
      org: "GenBI (Generasi Baru Indonesia)",
      period: "2023 — 2024",
      type: "Komunitas Penerima Beasiswa Bank Indonesia",
      desc: "Memimpin pengelolaan akun media sosial komunitas GenBI — mulai dari perencanaan konten, pembuatan desain, hingga penjadwalan publikasi. Bertanggung jawab membangun citra positif komunitas dan meningkatkan engagement audiens.",
      achievements: [
        "Mengelola akun Instagram & media sosial GenBI",
        "Merancang strategi konten & kalender publikasi",
        "Meningkatkan engagement dan jangkauan akun",
        "Mengkoordinasi tim kreatif untuk setiap kampanye",
      ],
      accent: "coral",
    },
  ],
  gallery: [
    { title: "Kegiatan GenBI", caption: "Kegiatan komunitas GenBI — Generasi Baru Indonesia" },
    { title: "Wisuda", caption: "Momen wisuda D4 Teknik Informatika PNL" },
    { title: "Produksi Konten", caption: "Menyusun konten media sosial komunitas" },
    { title: "Kegiatan Sosial", caption: "Aksi sosial & pengabdian masyarakat bersama komunitas" },
  ],
  socials: [
    { label: "GitHub", href: "https://github.com", handle: "@agungramadhan" },
    { label: "LinkedIn", href: "https://linkedin.com", handle: "Agung Ramadhan S." },
    { label: "Email", href: "mailto:agung.ramadhan@example.com", handle: "agung.ramadhan@example.com" },
  ],
} as const;
